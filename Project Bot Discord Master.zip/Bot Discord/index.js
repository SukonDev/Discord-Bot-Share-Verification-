import 'dotenv/config';
import {
  ActivityType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  MessageMentions,
  Partials,
  PermissionFlagsBits,
  REST,
  Routes
} from 'discord.js';
import { readFile } from 'node:fs/promises';

import detectImage from './detectImage.js';
import { setupTicketSystem } from './ticketHandler.js';

const config = JSON.parse(await readFile(new URL('./config.json', import.meta.url), 'utf8'));
const contactConfig = JSON.parse(await readFile(new URL('./contact.json', import.meta.url), 'utf8'));

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;

if (!token || !clientId) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in environment variables. Please configure .env.');
  process.exit(1);
}

const contacts = Array.isArray(contactConfig.contacts) ? contactConfig.contacts : [];
if (!contacts.length) {
  console.warn('[presence] contact.json has no contacts; rotating presence disabled.');
}

let presenceInterval = null;
let contactIndex = 0;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember]
});

setupTicketSystem(client, detectImage, config, contacts);

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Logged in as ${readyClient.user.tag}`);
  registerCommands().catch((error) => console.error('Failed to register slash commands:', error));
  startPresenceRotation(readyClient);
});

client.on(Events.MessageCreate, async (message) => {
  if (!config.deleteUnverifiedUrls) return;
  if (!message.guild || message.author.bot) return;
  if (message.channel.name?.startsWith('หลักฐาน-')) return;

  const content = message.content || '';
  const containsUrl =
    URL_REGEX.test(content) ||
    INVITE_REGEX.test(content) ||
    [...message.attachments.values()].some((attachment) => Boolean(attachment.url));

  const hasForbiddenKeyword = containsForbiddenKeyword(content);

  if (!containsUrl && !hasForbiddenKeyword) {
    resetRegexState();
    return;
  }

  if (MessageMentions.ChannelsPattern.test(content)) {
    resetRegexState();
    return;
  }

  const member = message.member ?? (await message.guild.members.fetch(message.author.id).catch(() => null));
  if (!member) return;
  if (member.roles.cache.has(config.verifiedRoleId)) return;
  if (config.adminRoleId && member.roles.cache.has(config.adminRoleId)) return;
  if (member.permissions.has(PermissionFlagsBits.ManageMessages)) return;

  try {
    await message.delete();
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle('🚫 ข้อความถูกลบเพื่อความปลอดภัย')
      .setDescription(
        [
          `ข้อความของคุณถูกลบเพราะตรวจพบลิงก์หรือเนื้อหาที่จำกัดสำหรับสมาชิกที่ยังไม่ผ่านการยืนยัน`,
          'กรุณาดำเนินการยืนยันตัวตนผ่านระบบหลักฐานก่อนโพสต์ลิงก์ในห้องสาธารณะ'
        ].join('\n')
      )
      .setFooter({ text: 'Saku Bot | Anti-Spam Protection' });

    const warning = await message.channel
      .send({
        content: `${message.author}`,
        embeds: [embed],
        allowedMentions: { users: [message.author.id] }
      })
      .catch(() => null);

    if (warning) {
      setTimeout(() => warning.delete().catch(() => null), 7000);
    }
  } catch (error) {
    console.error('Failed to delete restricted message:', error);
  } finally {
    resetRegexState();
  }
});

client.login(token);

process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection:', error);
});

const URL_REGEX = /(https?:\/\/[^\s]+)/gi;
const INVITE_REGEX = /(discord\.gg|discord\.com\/invite|invite\.gg)\/[A-Za-z0-9-]+/gi;
const FORBIDDEN_KEYWORDS = ['free nitro', 'nitro free', 'airdrop', 'scam', 'giveaway', 'ضغط هنا', '免费', 'telegram'];

async function registerCommands() {
  if (!config.guildId) {
    console.warn('Skipping slash command registration. Set guildId in config.json to register commands.');
    return;
  }

  const rest = new REST({ version: '10' }).setToken(token);
  await rest.put(Routes.applicationGuildCommands(clientId, config.guildId), {
    body: []
  });

  console.log('Cleared slash commands for guild:', config.guildId);
}

function containsForbiddenKeyword(content) {
  if (!content) return false;
  const lower = content.toLowerCase();
  return FORBIDDEN_KEYWORDS.some((keyword) => lower.includes(keyword));
}

function resetRegexState() {
  URL_REGEX.lastIndex = 0;
  INVITE_REGEX.lastIndex = 0;
}

function startPresenceRotation(readyClient) {
  if (!contacts.length) {
    readyClient.user.setPresence({
      activities: [{ name: 'Saku Bot พัฒนาโดย SukonDevZ', type: ActivityType.Playing }],
      status: 'online'
    });
    return;
  }

  const applyPresence = () => {
    const contact = contacts[contactIndex % contacts.length];
    contactIndex += 1;

    const icon = contact.icon || '🎮';
    const statusText = contact.status || `Saku Bot • ${contact.label}`;

    readyClient.user.setPresence({
      activities: [
        {
          name: `${icon} ${statusText}`,
          type: ActivityType.Playing
        }
      ],
      status: 'online'
    });
  };

  applyPresence();
  if (presenceInterval) clearInterval(presenceInterval);
  presenceInterval = setInterval(applyPresence, 30_000);
}
