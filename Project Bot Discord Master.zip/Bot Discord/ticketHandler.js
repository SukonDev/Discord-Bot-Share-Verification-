import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  WebhookClient
} from 'discord.js';
import fetch from 'node-fetch';

const DEFAULT_COLLECTION_TIME = 10 * 60 * 1000; // 10 minutes
const TICKET_TOPIC_PREFIX = 'ticket_user:';

/**
 * Sets up the ticket system button panel and handlers.
 * @param {import('discord.js').Client} client
 * @param {(attachments: Array<{ buffer: Buffer, fileName: string }>, config: Record<string, any>) => Promise<{
 *   matched: boolean,
 *   invites: string[],
 *   otherUrls: string[],
 *   averageConfidence: number,
 *   ocrText: string,
 *   looksLikeDiscord: boolean,
 *   discordKeywords: string[],
 *   duplicates: Array<{ primary: string, duplicate: string, distance: number }>,
 *   hasDuplicate: boolean
 * }>} detectImage
 * @param {Record<string, any>} config
 * @param {Array<{ label: string, display: string, url?: string }>} contacts
 */
export function setupTicketSystem(client, detectImage, config, contacts = []) {
  const webhookClient = config.webhookUrl ? new WebhookClient({ url: config.webhookUrl }) : null;
  const maxImages = Number(config.maxImages) || 3;

  client.once('ready', async () => {
    if (!config.ticketPanelChannelId) {
      console.warn('[ticketHandler] No ticketPanelChannelId configured; skipping ticket panel deployment.');
      return;
    }

    try {
      const panelChannel = await client.channels.fetch(config.ticketPanelChannelId);
      if (!panelChannel?.isTextBased()) {
        console.warn('[ticketHandler] Configured ticket panel channel is not text-based.');
        return;
      }

      // Prevent duplicate panels by checking for an existing button with the same customId.
      const recentMessages = await panelChannel.messages.fetch({ limit: 20 }).catch(() => null);
      const existing = recentMessages?.find((message) => {
        if (message.author.id !== client.user.id) return false;
        return message.components.some((row) =>
          row.components.some((component) => component.customId === 'create_ticket')
        );
      });

      if (existing) return;

      const embed = buildTicketPanelEmbed(maxImages, contacts);
      const button = new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('เปิดห้องหลักฐาน')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🎫');

      const components = [
        new ActionRowBuilder().addComponents(button),
        ...buildContactButtons(contacts)
      ];

      await panelChannel.send({
        embeds: [embed],
        components
      });

      console.log('[ticketHandler] Ticket panel deployed.');
    } catch (error) {
      console.error('[ticketHandler] Failed to deploy ticket panel:', error);
    }
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() || interaction.customId !== 'create_ticket') return;
    const member = interaction.member ?? (await interaction.guild?.members.fetch(interaction.user.id).catch(() => null));
    if (member?.roles.cache.has(config.verifiedRoleId)) {
      await interaction.reply({
        ephemeral: true,
        embeds: [
          new EmbedBuilder()
            .setColor(0x2ecc71)
            .setTitle('🛡️ คุณมีสถานะ Verified')
            .setDescription('บัญชีของคุณได้รับการยืนยันเรียบร้อยแล้ว จึงไม่จำเป็นต้องเปิดห้องหลักฐานใหม่')
        ]
      });
      return;
    }
    await handleTicketButton(interaction, detectImage, config, webhookClient, contacts);
  });
}

async function handleTicketButton(interaction, detectImage, config, webhookClient, contacts) {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.reply({
      ephemeral: true,
      embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('⚠️ ใช้ได้เฉพาะในเซิร์ฟเวอร์')
          .setDescription('คำสั่งนี้สามารถใช้ได้เฉพาะภายในเซิร์ฟเวอร์เท่านั้น')
      ]
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  await guild.channels.fetch().catch(() => null);
  const existingChannel =
    guild.channels.cache.find(
      (channel) =>
        channel.type === ChannelType.GuildText &&
        channel.topic === `${TICKET_TOPIC_PREFIX}${interaction.user.id}`
    ) ||
    guild.channels.cache.find(
      (channel) =>
        channel.type === ChannelType.GuildText &&
        channel.name === `หลักฐาน-${interaction.user.id}`
    );

  if (existingChannel) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xe67e22)
          .setTitle('⚠️ มีห้องหลักฐานอยู่แล้ว')
          .setDescription(`คุณมีห้องหลักฐานที่ยังเปิดใช้งานอยู่: <#${existingChannel.id}>`)
      ]
    });
    return;
  }

  const member = interaction.member ?? (await guild.members.fetch(interaction.user.id).catch(() => null));
  const channelName = buildTicketChannelName(member, interaction.user);
  const permissionOverwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel]
    },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ReadMessageHistory
      ]
    }
  ];

  if (config.adminRoleId) {
    permissionOverwrites.push({
      id: config.adminRoleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages
      ]
    });
  }

  const channelPayload = {
    name: channelName,
    type: ChannelType.GuildText,
    permissionOverwrites,
    topic: `${TICKET_TOPIC_PREFIX}${interaction.user.id}`,
    reason: `Ticket opened by ${interaction.user.tag} (${interaction.user.id})`
  };

  if (config.ticketParentId) {
    channelPayload.parent = config.ticketParentId;
  }

  try {
    const ticketChannel = await guild.channels.create(channelPayload);
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x3498db)
          .setTitle('🎫 เปิดห้องสำเร็จ')
          .setDescription(`ระบบสร้างห้องหลักฐานให้คุณแล้ว: <#${ticketChannel.id}>`)
      ]
    });

    const instructions = buildTicketInstructionsEmbed(config.maxImages, contacts);
    await ticketChannel.send({
      content: `<@${interaction.user.id}>`,
      embeds: [instructions],
      components: buildContactButtons(contacts)
    });

    await collectEvidence(ticketChannel, interaction.user, detectImage, config, webhookClient, contacts);
  } catch (error) {
    console.error('[ticketHandler] Failed to create ticket channel:', error);
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('❌ ไม่สามารถสร้างห้องได้')
          .setDescription('เกิดข้อผิดพลาดในการสร้างห้องหลักฐาน กรุณาแจ้งผู้ดูแลระบบ')
      ]
    });
  }
}

async function collectEvidence(channel, user, detectImage, config, webhookClient, contacts) {
  const maxImages = Number(config.maxImages) || 3;
  const collected = [];
  const pendingMessages = new Map();

  const collector = channel.createMessageCollector({
    filter: (message) => message.author.id === user.id && message.attachments.size > 0,
    time: DEFAULT_COLLECTION_TIME
  });

  collector.on('collect', async (message) => {
    pendingMessages.set(message.id, true);

    for (const attachment of message.attachments.values()) {
      if (collected.length >= maxImages) break;
      if (!isImageAttachment(attachment)) continue;

      try {
        const response = await fetch(attachment.url);
        if (!response.ok) throw new Error(`Failed to fetch attachment: ${response.status} ${response.statusText}`);
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        const extension = guessExtension(attachment);
        const fileName = `${Date.now()}-${user.id}-${collected.length + 1}${extension}`;

        collected.push({
          buffer,
          fileName,
          originalUrl: attachment.url
        });
      } catch (error) {
        console.error('[ticketHandler] Failed to download attachment:', error);
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe74c3c)
              .setTitle('⚠️ รับไฟล์ไม่สำเร็จ')
              .setDescription('ไม่สามารถดาวน์โหลดไฟล์บางไฟล์ได้ กรุณาลองส่งใหม่')
          ]
        });
      }
    }

    await message.react('✅').catch(() => null);
    pendingMessages.delete(message.id);

    if (collected.length >= maxImages) {
      collector.stop('complete');
    } else {
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0x1abc9c)
            .setTitle('🖼️ รับไฟล์แล้ว')
            .setDescription(`ได้รับไฟล์รวม ${collected.length}/${maxImages} กรุณาส่งให้ครบจำนวนที่กำหนด`)
        ]
      });
    }
  });

  collector.on('end', async (_, reason) => {
    if (reason !== 'complete') {
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xe74c3c)
            .setTitle('⏱️ หมดเวลา')
            .setDescription('หมดเวลาเก็บรวบรวมไฟล์หลักฐาน กรุณากดปุ่มเพื่อเปิดห้องใหม่อีกครั้ง')
        ]
      });
      for (const messageId of pendingMessages.keys()) {
        const message = await channel.messages.fetch(messageId).catch(() => null);
        if (message) await message.react('⚠️').catch(() => null);
      }
      scheduleChannelDeletion(channel, 'Evidence collection timed out', 15_000);
      return;
    }

    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0x9b59b6)
          .setTitle('🔍 กำลังประมวลผล')
          .setDescription('ระบบกำลังตรวจสอบข้อความและลิงก์ในภาพของคุณ กรุณารอสักครู่...')
      ]
    });

    try {
      const analysis = await detectImage(collected, config);
      const duplicatesFound = Boolean(analysis.hasDuplicate);
      const matched = Boolean(analysis.matched) && !duplicatesFound;

      const resultEmbed = new EmbedBuilder()
        .setTitle('ผลการตรวจสอบหลักฐาน')
        .setColor(matched ? 0x2ecc71 : 0xe74c3c)
        .addFields(
          { name: 'จำนวนไฟล์', value: `${collected.length}`, inline: true },
          {
            name: 'ลิงก์ที่ตรวจพบ',
            value: (analysis.invites.length ? analysis.invites.join('\n') : 'ไม่พบ') ?? 'ไม่พบ',
            inline: false
          },
          {
            name: 'ลิงก์อื่น ๆ',
            value: analysis.otherUrls.length ? analysis.otherUrls.join('\n') : 'ไม่พบ',
            inline: false
          },
          {
            name: 'ความเชื่อมั่นเฉลี่ย',
            value: `${analysis.averageConfidence.toFixed(2)}%`,
            inline: true
          },
          {
            name: 'สถานะ',
            value: matched ? '✅ ตรวจสอบผ่าน' : '❌ ไม่พบลิงก์ที่ตรงตามเงื่อนไข',
            inline: true
          },
          {
            name: 'ความซ้ำของภาพ',
            value: analysis.duplicates?.length
              ? formatDuplicatePairs(analysis.duplicates)
              : 'ไม่พบภาพซ้ำหรือใกล้เคียงกัน',
            inline: false
          },
          {
            name: 'ลักษณะภาพ',
            value: analysis.looksLikeDiscord
              ? '✅ มีองค์ประกอบที่เหมือนภาพจาก Discord'
              : '⚠️ ไม่พบองค์ประกอบ Discord ชัดเจน',
            inline: false
          }
        )
        .setTimestamp();

      if (analysis.discordKeywords?.length) {
        resultEmbed.addFields({
          name: 'คีย์เวิร์ดที่ตรวจพบ',
          value: analysis.discordKeywords.slice(0, 6).join(', '),
          inline: false
        });
      }

      await channel.send({ embeds: [resultEmbed] });

      if (webhookClient) {
        await sendLog(webhookClient, channel, user, collected, analysis, matched);
      }

      if (analysis.duplicates?.length) {
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe67e22)
              .setTitle('⚠️ พบภาพหลักฐานซ้ำหรือใกล้เคียง')
              .setDescription(
                [
                  'ระบบตรวจพบว่ามีภาพบางส่วนที่เหมือนหรือคล้ายกันมากเกินไป',
                  'กรุณาจัดเตรียมภาพหลักฐานที่แตกต่างอย่างชัดเจนแล้วเปิดห้องหลักฐานใหม่อีกครั้ง'
                ].join('\n')
              )
              .addFields({
                name: 'รายละเอียด',
                value: formatDuplicatePairs(analysis.duplicates)
              })
          ]
        });

        scheduleChannelDeletion(channel, 'Duplicate evidence detected', 20_000);
        return;
      }

      if (!matched) {
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe74c3c)
              .setTitle('❌ ยังไม่ผ่านการตรวจสอบ')
              .setDescription(
                'ระบบไม่พบลิงก์ที่ตรงกับชุมชนของเรา กรุณากดปุ่มเพื่อเปิดห้องใหม่แล้วส่งหลักฐานที่ถูกต้องอีกครั้ง'
              )
          ]
        });
        scheduleChannelDeletion(channel, 'Evidence did not match requirements', 15_000);
        return;
      }

      const member = await channel.guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe74c3c)
              .setTitle('⚠️ ไม่พบข้อมูลสมาชิก')
              .setDescription('ไม่พบข้อมูลสมาชิกของคุณในเซิร์ฟเวอร์ ไม่สามารถมอบบทบาทได้')
          ]
        });
        return;
      }

      if (!config.verifiedRoleId) {
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe74c3c)
              .setTitle('⚙️ ยังไม่ได้ตั้งค่าบทบาท')
              .setDescription('ยังไม่ได้กำหนดบทบาท Verified ใน config.json กรุณาแจ้งผู้ดูแลระบบ')
          ]
        });
        return;
      }

      await member.roles.add(config.verifiedRoleId, 'Evidence verified by bot');
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0x2ecc71)
            .setTitle('✅ ผ่านการตรวจสอบ')
            .setDescription('ระบบมอบบทบาทให้เรียบร้อยแล้ว ห้องนี้จะถูกลบใน 10 วินาที')
        ]
      });

      await member
        .send({
          content: `<@${member.id}>`,
          embeds: [
            new EmbedBuilder()
              .setColor(0x2ecc71)
              .setTitle('🎉 ยินดีด้วย! คุณผ่านการยืนยันแล้ว')
              .setDescription(
                [
                  `คุณได้รับบทบาทใหม่ใน **${channel.guild.name}**`,
                  'ขอบคุณที่ส่งหลักฐานให้ทีมงานตรวจสอบเรียบร้อย',
                  'คุณสามารถเริ่มเข้าร่วมชุมชนได้เต็มรูปแบบจากนี้ไป'
                ].join('\n')
              )
              .setFooter({
                text: formatContactFooter(contacts) || 'Saku Bot | Developed by SukonDevZ'
              })
              .setTimestamp()
          ]
        })
        .catch(() => null);

      scheduleChannelDeletion(channel, 'Verification complete', 10_000);
    } catch (error) {
      console.error('[ticketHandler] Failed to analyse evidence:', error);
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xe74c3c)
            .setTitle('❌ เกิดข้อผิดพลาด')
            .setDescription('เกิดข้อผิดพลาดในการประมวลผล กรุณาลองใหม่ภายหลัง')
        ]
      });
    }
  });
}

function isImageAttachment(attachment) {
  if (attachment.contentType?.startsWith('image/')) return true;
  return /\.(png|jpe?g|webp)$/i.test(attachment.name || '');
}

function guessExtension(attachment) {
  if (attachment.name && /\.[a-zA-Z0-9]+$/.test(attachment.name)) {
    return attachment.name.match(/\.[a-zA-Z0-9]+$/)[0].toLowerCase();
  }
  if (attachment.contentType?.includes('png')) return '.png';
  if (attachment.contentType?.includes('jpeg')) return '.jpg';
  if (attachment.contentType?.includes('webp')) return '.webp';
  return '.png';
}

function buildTicketChannelName(member, user) {
  const displayName = member?.displayName ?? user.globalName ?? user.username ?? user.id;
  const sanitized = sanitizeTicketSegment(displayName);
  let channelName = `หลักฐาน-${sanitized || 'ผู้ใช้'}`;
  if (channelName.length > 90) {
    channelName = `${channelName.slice(0, 90)}...`;
  }
  return channelName;
}

function sanitizeTicketSegment(value) {
  return value
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^0-9A-Za-z\u0E00-\u0E7F\-_.]/g, '')
    .replace(/-+/g, '-')
    .replace(/^[-_.]+|[-_.]+$/g, '')
    .toLowerCase();
}

function scheduleChannelDeletion(channel, reason, delayMs = 10_000) {
  setTimeout(() => {
    if (!channel.deletable) return;
    channel.delete(reason).catch((error) => {
      console.error('[ticketHandler] Failed to delete ticket channel:', error);
    });
  }, delayMs);
}

async function sendLog(webhookClient, channel, user, attachments, analysis, matched) {
  try {
    const embed = new EmbedBuilder()
      .setTitle('Ticket Processed')
      .setColor(matched ? 0x2ecc71 : 0xe74c3c)
      .addFields(
        { name: 'User', value: `${user.tag} (${user.id})` },
        { name: 'Channel', value: channel.name },
        {
          name: 'Detected Invites',
          value: analysis.invites.length ? analysis.invites.join('\n') : 'None'
        },
        {
          name: 'Other URLs',
          value: analysis.otherUrls.length ? analysis.otherUrls.join('\n') : 'None'
        },
        {
          name: 'Average Confidence',
          value: `${analysis.averageConfidence.toFixed(2)}%`
        },
        {
          name: 'Matched Target',
          value: matched ? 'Yes' : 'No',
          inline: true
        },
        {
          name: 'Discord Screenshot',
          value: analysis.looksLikeDiscord
            ? `Likely (keywords: ${formatKeywordList(analysis.discordKeywords)})`
            : 'Unclear / needs manual review'
        },
        {
          name: 'Duplicate Check',
          value: analysis.duplicates?.length
            ? formatDuplicatePairs(analysis.duplicates)
            : 'No duplicates detected'
        }
      )
      .setTimestamp();

    if (analysis.ocrText?.length) {
      embed.setDescription(truncate(analysis.ocrText, 1900));
    }

    const files = attachments.map(
      (attachment) => new AttachmentBuilder(attachment.buffer, { name: attachment.fileName })
    );

    await webhookClient.send({
      username: 'Evidence Logger',
      embeds: [embed],
      files
    });
  } catch (error) {
    console.error('[ticketHandler] Failed to send webhook log:', error);
  }
}

function truncate(text, maxLength) {
  if (!text || text.length <= maxLength) return text;
  return `${text.slice(0, maxLength - 3)}...`;
}

function formatKeywordList(keywords) {
  if (!Array.isArray(keywords) || !keywords.length) return 'none';
  return keywords.slice(0, 6).join(', ');
}

function formatDuplicatePairs(pairs) {
  if (!Array.isArray(pairs) || !pairs.length) return 'No duplicates detected';
  return pairs
    .slice(0, 5)
    .map((pair) => `• ${pair.primary} ↔ ${pair.duplicate} (dist: ${pair.distance})`)
    .join('\n');
}

function buildTicketPanelEmbed(maxImages, contacts) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('🛡️ ระบบยืนยันหลักฐาน')
    .setDescription('ปกป้องชุมชนด้วยการตรวจสอบหลักฐานก่อนเข้าร่วมเต็มรูปแบบ')
    .addFields(
      {
        name: 'ขั้นตอนที่ 1',
        value: 'กดปุ่ม **เปิดห้องหลักฐาน** เพื่อสร้างห้องส่วนตัว'
      },
      {
        name: 'ขั้นตอนที่ 2',
        value: `อัปโหลดภาพหลักฐานจำนวน **${maxImages}** รูปภายในเวลาที่กำหนด`
      },
      {
        name: 'ขั้นตอนที่ 3',
        value: 'รอระบบ OCR ตรวจสอบลิงก์และข้อความอัตโนมัติ จากนั้นรอทีมงานยืนยัน'
      }
    );

  const contactFooter = formatContactFooter(contacts);
  if (contactFooter) {
    embed.addFields({ name: '📞 ติดต่อผู้พัฒนา', value: contactFooter });
    embed.setFooter({ text: contactFooter });
  } else {
    embed.setFooter({ text: 'Saku Bot | เพิ่มความปลอดภัยให้ทุกคน' });
  }

  return embed;
}

function buildTicketInstructionsEmbed(maxImages, contacts) {
  const embed = new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle('📌 คู่มือการส่งหลักฐาน')
    .setDescription('กรุณาปฏิบัติตามข้อกำหนดด้านล่างเพื่อให้การตรวจสอบรวดเร็วและแม่นยำ')
    .addFields(
      {
        name: '⏱️ กำหนดเวลา',
        value: 'ส่งหลักฐานให้ครบภายใน **10 นาที** หลังจากเปิดห้อง'
      },
      {
        name: '📁 จำนวน/ประเภทไฟล์',
        value: `อัปโหลดภาพจำนวน **${maxImages}** รูป (รองรับ PNG / JPG / JPEG / WebP)`
      },
      {
        name: '🔍 การตรวจสอบ',
        value: 'ระบบจะทำ OCR ตรวจหาข้อความและลิงก์ที่เกี่ยวข้องกับชุมชนโดยอัตโนมัติ รวมถึงวิเคราะห์ความซ้ำของภาพ'
      },
      {
        name: '💡 เคล็ดลับ',
        value: 'ใช้ภาพจากหน้าต่าง Discord จริง หลีกเลี่ยงการตัดต่อหรือภาพเบลอเพื่อเพิ่มความน่าเชื่อถือ'
      }
    );

  const contactFooter = formatContactFooter(contacts);
  if (contactFooter) {
    embed.addFields({ name: '📞 ติดต่อผู้พัฒนา', value: contactFooter });
    embed.setFooter({ text: contactFooter });
  } else {
    embed.setFooter({
      text: 'Saku Bot | ทีมงานตรวจสอบอย่างเข้มงวด'
    });
  }

  return embed;
}

function buildContactButtons(contacts) {
  if (!Array.isArray(contacts) || !contacts.length) return [];

  const linkButtons = contacts
    .filter((contact) => contact?.url)
    .map((contact) => {
      const button = new ButtonBuilder()
        .setStyle(ButtonStyle.Link)
        .setURL(contact.url)
        .setLabel(contact.label || contact.display || 'Contact');
      if (contact.icon) {
        button.setEmoji(contact.icon);
      }
      return button;
    });

  if (!linkButtons.length) return [];

  const rows = [];
  for (let i = 0; i < linkButtons.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(...linkButtons.slice(i, i + 5)));
  }
  return rows;
}

function formatContactFooter(contacts) {
  if (!Array.isArray(contacts) || !contacts.length) return '';
  const values = contacts.map((contact) => contact.display || contact.label).filter(Boolean);
  return values.join(' • ');
}
