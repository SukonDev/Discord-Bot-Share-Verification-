import Tesseract from 'tesseract.js';
import Jimp from 'jimp';

const INVITE_REGEX = /(discord\.gg|discord\.com\/invite|invite\.gg)\/[A-Za-z0-9-]+/gi;
const URL_REGEX = /https?:\/\/[^\s)]+/gi;
const DISCORD_KEYWORDS = [
  'discord',
  'text channels',
  'voice channels',
  'members',
  'mutual servers',
  'mutual friends',
  'invite',
  'report',
  'block',
  'mark as read',
  'message',
  'threads',
  'server boost',
  'create channel',
  'pinned messages',
  'inbox'
];
const DUPLICATE_DISTANCE_THRESHOLD = 5;

/**
 * Performs OCR on the provided images and detects invite links / URLs.
 * Also heuristically determines whether the image resembles a Discord screenshot.
 * @param {Array<{ buffer: Buffer, fileName: string }>} attachments
 * @param {Record<string, any>} config
 */
export default async function detectImage(attachments, config = {}) {
  const inviteSet = new Set();
  const urlSet = new Set();
  const textChunks = [];
  const keywordHits = new Set();
  const descriptors = [];
  let confidenceTotal = 0;
  let processedCount = 0;
  const tesseractLanguages = resolveOcrLanguages(config);

  for (const attachment of attachments) {
    try {
      const { data } = await Tesseract.recognize(attachment.buffer, tesseractLanguages);
      const text = (data.text || '').trim();
      textChunks.push(formatTextChunk(attachment.fileName, text));

      const normalizedInvites = extractInvites(text);
      normalizedInvites.forEach((link) => inviteSet.add(link));

      const normalizedUrls = extractUrls(text);
      normalizedUrls.forEach((link) => urlSet.add(link));

      collectDiscordKeywords(text, keywordHits);

      const hash = await computePerceptualHash(attachment.buffer).catch((error) => {
        console.error(`[detectImage] Failed to hash ${attachment.fileName}:`, error);
        return null;
      });

      if (hash) {
        descriptors.push({
          fileName: attachment.fileName,
          hash
        });
      }

      if (Number.isFinite(data.confidence)) {
        confidenceTotal += data.confidence;
        processedCount += 1;
      }
    } catch (error) {
      console.error(`[detectImage] Failed to process ${attachment.fileName}:`, error);
    }
  }

  const invites = Array.from(inviteSet).map(prettyLink);
  const otherUrls = Array.from(urlSet)
    .filter((url) => !inviteSet.has(url))
    .map(prettyLink);

  const normalizedTargets = (config.targetLinks || []).map(normalizeLink).filter(Boolean);
  const matched = invites.map(normalizeLink).some((link) => normalizedTargets.includes(link));

  const looksLikeDiscord = evaluateDiscordScreenshot(invites.length, keywordHits);
  const duplicatePairs = buildDuplicateReport(descriptors);

  return {
    matched,
    invites,
    otherUrls,
    averageConfidence: processedCount ? confidenceTotal / processedCount : 0,
    ocrText: textChunks.join('\n\n'),
    looksLikeDiscord,
    discordKeywords: Array.from(keywordHits.values()).sort(),
    duplicates: duplicatePairs,
    hasDuplicate: duplicatePairs.length > 0
  };
}

function extractInvites(text) {
  const matches = text.match(INVITE_REGEX) || [];
  return matches.map(normalizeLink).filter(Boolean);
}

function extractUrls(text) {
  const matches = text.match(URL_REGEX) || [];
  return matches.map(normalizeLink).filter(Boolean);
}

function normalizeLink(link) {
  if (!link) return null;
  return link
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '');
}

function prettyLink(link) {
  if (!link) return '';
  return link.startsWith('http') ? link : `https://${link}`;
}

function formatTextChunk(fileName, text) {
  const header = `📄 ${fileName || 'attachment'}`;
  if (!text) return `${header}\n(ไม่พบข้อความ)`;
  return `${header}\n${text}`;
}

function resolveOcrLanguages(config) {
  const languages = config?.ocrLanguages;
  if (Array.isArray(languages)) {
    const cleaned = languages.map((lang) => String(lang || '').trim()).filter(Boolean);
    if (cleaned.length) return cleaned.join('+');
  } else if (typeof languages === 'string' && languages.trim().length) {
    return languages.trim();
  }
  return 'eng+tha';
}

function collectDiscordKeywords(text, keywordHits) {
  if (!text) return;
  const lowerText = text.toLowerCase();
  for (const keyword of DISCORD_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      keywordHits.add(keyword);
    }
  }
}

function evaluateDiscordScreenshot(inviteCount, keywordHits) {
  if (keywordHits.size >= 3) return true;
  if (inviteCount > 0 && keywordHits.size >= 1) return true;
  return false;
}

async function computePerceptualHash(buffer) {
  const image = await Jimp.read(buffer);
  return image.hash();
}

function buildDuplicateReport(descriptors) {
  if (!descriptors.length) return [];
  const report = [];
  for (let i = 0; i < descriptors.length; i += 1) {
    for (let j = i + 1; j < descriptors.length; j += 1) {
      const hashA = descriptors[i].hash;
      const hashB = descriptors[j].hash;
      if (!hashA || !hashB) continue;
      const distance = hammingDistance(hashA, hashB);
      if (distance <= DUPLICATE_DISTANCE_THRESHOLD) {
        report.push({
          primary: descriptors[i].fileName,
          duplicate: descriptors[j].fileName,
          distance
        });
      }
    }
  }
  return report;
}

function hammingDistance(hashA, hashB) {
  const normalizedA = normalizeHash(hashA);
  const normalizedB = normalizeHash(hashB);
  const valueA = BigInt(`0x${normalizedA}`);
  const valueB = BigInt(`0x${normalizedB}`);
  let xor = valueA ^ valueB;
  let distance = 0n;
  while (xor > 0n) {
    distance += xor & 1n;
    xor >>= 1n;
  }
  return Number(distance);
}

function normalizeHash(hash) {
  return String(hash || '')
    .trim()
    .toLowerCase()
    .replace(/[^0-9a-f]/g, '')
    .padEnd(16, '0');
}
